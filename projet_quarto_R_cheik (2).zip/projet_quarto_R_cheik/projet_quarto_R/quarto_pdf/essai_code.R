#pour creer des listes
nom  <- c("amala" , "papi" , "harouna")
age  <- c(12,13,13)
ense  <- list(nom , age)
ense

#pour creer un dataframe

donne  <- data.frame(nom , age)
donne

# pour obtenir l'ensemble des caractere d'une varaible

vecteur  <- factor(nom)
vecteur

#indexation de colonne



mean(donne$age)

# a la place du $ on peut utiliser with

with(donne , mean(age))

#pour le nombre de ligne et de colonne

nrow(donne)

ncol(donne)

# pour ajouter une colonn, on utilise cbind

aptitude  <- c("bon" , "assez bon" , "moyen")
donne  <- cbind(donne , aptitude)
donne

#utilisation des boucles

n  <- c(1:10)
n

#1ere utilisation
yy  <- NULL
for (i in 1: length(n)){
  if (n[i]%%2 == 0) {yy[i]  <- "Even"}
  else{yy[i] <- "ODD"}
}
yy

#2eme utilisation

colo <- NULL
cre <- c(1:20)

for (i in 1: length(cre)){
  if (cre[i]%%2 ==0){colo[i] <- "bien"}
  else{colo[i] <- "mieux"}
}
colo

#indexe les colonnes qui nous interesse uniquement dans un dataframe
#avec na.rm = True on autorise R a ne pas considerer les variables manquantes
donne1 <- subset(micro_world , select = c("economy" , "pop_adult" , "age"))
head(donne1)
mean(donne1$age , na.rm = TRUE)

# de meme subset nous permet de selectionner suivant un critere bien definis

donne2 <- subset(micro_world , age == 40 , select = c("economy" , "pop_adult" , "age"))
donne2
mean(donne2$age)
names(donne2)
nrow(donne2)

#faire un regression lineaire entre la population et l'age

regression <- lm(age ~ pop_adult , data = donne2 )
regression
summary(regression)

library(tidyverse)
#elle fait la meme chose que R mais avec des fonctions beaucoup plus poussées
#drop_na supprime les lignes qui possede des donnee manquantes

donne_supprime <- drop_na(donne2)
donne_supprime
nrow(donne_supprime)
regression2 <- lm(pop_adult ~ age ,data = donne_supprime)
regression2

drop_na(donne_supprime)

library(tidyverse)

head(micro_world1)
donne_corrige <- drop_na(micro_world1)

#affichage

head(donne_corrige)
colnames(donne_corrige)

#graphique

head(cars)
edit(cars)

#histogramme 

valeur_hist <- cars[1:10 , 1]
valeur_hist <- data.frame(valeur_hist)
valeur_hist

hist(valeur_hist)

#pour les histogrammes
hist(cars$dist ,xlim = c(0,80) ,  xlab = "distance" , ylab = "frequence" , main = "histogramme")

#on peut egalement lineariser les variables avec probabilité, la elle etablit les données sur la meme base de en pourcentage

hist(cars$dist , probability = TRUE)

line(density(cars$dist))

table(cars$dist)

# la definition de space permet de mettre de l'espace entre les données 
# table permet de creer des intervalles ce qui facilite la representation
barplot(table(cars$dist) , space = .05)

#pie est utilisé pour faire des diagrammes circulaires
pie(table(cars$dist))

revenu <- c(1000,1300,1300,1100,1400,800,1200,1500,1850,2330,860,1300,1400,
  1600,1970,570,380,450,465,580,155,190,210,250,300)

#le fait de designer par byrow permet de lister suivant la ligne

matrice <- matrix(revenu , nrow = 5 , byrow = TRUE )
matrice

# you can changes values of lines and columns

colnames(matrice) <- c(1990, 2000, 2010, 2020, 2030)

rownames(matrice) <- c("allumettes" , "café" , "boissons", "bougie" ,"produits menager")

matrice

# on peut egalement definir des couleurs qui peuvent etre applique au histogramme

barplot(cars$dist , xlab = "distance" , ylab = "frequence" , col = "red")


#de meme on peut faire un graphique avec 2 variables
#pch est utilisé pour faire determiner la taille des points dans le nuage de point
plot(cars$speed , cars$dist  , main = "nuage de point" , col = "red" , pch = 1)

boxplot(cars$speed ~ cars$dist )


library(ggplot2)
#fill permet de selectionner la couleur de fond du graphique
ggplot(cars , aes (x = speed ))+
  geom_histogram(color = "blue" , fill = "yellow" , binwidth = 4)+
  labs(x  = "vitesse" , y = "frequence" , title = "histogramme")

ggplot(cars , aes(x = speed))+
  geom_bar(fill = "green")+
  labs(x = "vitesse" , y = "frequence" , title = "plots")

val<-data.frame( table(cars$dist))
val

ggplot(val ,aes(x = Var1 , y = Freq))+
  geom_point(fill = "black" , size = 2)+
  labs(title = "nuage de point")

ggplot(val ,aes(x = Var1 , y = Freq))+
  geom_point(size = 4) +
  theme_bw() +
  theme(panel.grid.major.x=element_blank(),
        panel.grid.major.y=element_line(color = "black",linetype = "dotted"))+
  labs(y="Type")

head(iris)

ggplot(iris , aes(x = Sepal.Length , y = Sepal.Width))+
  geom_point(size = 2)+
  theme_bw()+
  theme(panel.grid.major.x = element_blank(),
        panel.grid.major.y = element_line(color = "red"))+
  labs(title = "graphiques")

data()

head(beaver1)  

ggplot(beaver1 , aes(x = temp , y = time))+
  geom_point(size = 0.5 , color = "navy")+
  theme_bw()+
  theme(panel.grid.major.x = element_line(color = "black" , size = 1),
        panel.grid.minor.y = element_line(color = "red" , size = 1))+
  labs(title = "graphiques" , position = "dodge")+
  theme(panel.grid =element_blank())

head(beaver1)

donne6 <- subset(beaver1 , select = c("day" , "time"))

library(GGally)

ggpairs(donne6)
